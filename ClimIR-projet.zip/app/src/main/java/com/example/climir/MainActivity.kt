package com.example.climir

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.app.Activity

class MainActivity : Activity() {

    private lateinit var ir: ConsumerIrManager
    private lateinit var info: TextView
    private var idx = 0
    private var temp = 24
    private val names = listOf("Gree A", "Gree B", "Coolix", "Midea")

    // ---------- Construction des signaux ----------
    private fun addBits(p: MutableList<Int>, v: Int, n: Int, msb: Boolean,
                        mark: Int, one: Int, zero: Int) {
        for (i in 0 until n) {
            val bit = if (msb) (v shr (n - 1 - i)) and 1 else (v shr i) and 1
            p.add(mark); p.add(if (bit == 1) one else zero)
        }
    }

    private fun gree(on: Boolean, t: Int, b2: Int): IntArray {
        val b = IntArray(8)
        b[0] = if (on) 0x09 else 0x01
        b[1] = t - 16
        b[2] = b2
        b[3] = 0x50
        val sum = 10 + (b[0] and 15) + (b[1] and 15) + (b[2] and 15) + (b[3] and 15) +
                (b[4] shr 4) + (b[5] shr 4) + (b[6] shr 4)
        b[7] = (sum and 15) shl 4
        val p = mutableListOf(9000, 4500)
        for (i in 0..3) addBits(p, b[i], 8, false, 620, 1600, 540)
        addBits(p, 0b010, 3, false, 620, 1600, 540)      // pied de bloc
        p.add(620); p.add(19000)
        for (i in 4..7) addBits(p, b[i], 8, false, 620, 1600, 540)
        p.add(620)
        return p.toIntArray()
    }

    private fun coolix(on: Boolean, t: Int): IntArray {
        val tmap = mapOf(17 to 0, 18 to 1, 19 to 3, 20 to 2, 21 to 6, 22 to 7, 23 to 5,
            24 to 4, 25 to 12, 26 to 13, 27 to 9, 28 to 8, 29 to 10, 30 to 11)
        val code = if (on) 0xB2BF00 or ((tmap[t] ?: 4) shl 4) else 0xB27BE0
        val bytes = intArrayOf((code shr 16) and 255, (code shr 8) and 255, code and 255)
        val p = mutableListOf<Int>()
        repeat(2) {
            p.add(4480); p.add(4480)
            for (b in bytes) {
                addBits(p, b, 8, true, 560, 1680, 560)
                addBits(p, b.inv() and 255, 8, true, 560, 1680, 560)
            }
            p.add(560); p.add(5040)
        }
        return p.toIntArray()
    }

    private fun midea(on: Boolean): IntArray {
        val bytes = if (on) intArrayOf(0xA1, 0x82, 0x6F, 0xFF, 0xFF, 0x62)
        else intArrayOf(0xA2, 0x01, 0xFF, 0xFF, 0xFF, 0x7E)
        val p = mutableListOf<Int>()
        repeat(2) {
            p.add(4480); p.add(4480)
            for (b in bytes) addBits(p, b, 8, true, 560, 1680, 560)
            p.add(560); p.add(5600)
        }
        return p.toIntArray()
    }

    private fun frame(i: Int, on: Boolean, t: Int): IntArray = when (i) {
        0 -> gree(on, t, 0x20)
        1 -> gree(on, t, 0x00)
        2 -> coolix(on, t)
        else -> midea(on)
    }

    private fun send(i: Int, on: Boolean) {
        if (!ir.hasIrEmitter()) { info.text = "Pas d'émetteur IR détecté."; return }
        ir.transmit(38000, frame(i, on, temp))
    }

    // ---------- Interface ----------
    private fun btn(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager
        val prefs = getSharedPreferences("clim", MODE_PRIVATE)
        val saved = prefs.getInt("proto", -1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        info = TextView(this).apply { textSize = 18f }
        root.addView(info)
        fun refresh() {
            info.text = "Test : ${names[idx]}   |   Température : $temp °C\n" +
                    (if (saved >= 0) "Code enregistré : ${names[saved]}" else "Aucun code enregistré")
        }
        refresh()

        root.addView(TextView(this).apply { text = "\n1) Trouver le bon code (pointe vers la clim)"; textSize = 16f })
        btn(root, "Envoyer MARCHE (code testé)") { send(idx, true) }
        btn(root, "Ça a marché ! Enregistrer") {
            prefs.edit().putInt("proto", idx).apply()
            info.text = "Enregistré : ${names[idx]}. Redémarre l'app pour l'utiliser."
        }
        btn(root, "Suivant ➜") { idx = (idx + 1) % names.size; refresh() }

        root.addView(TextView(this).apply { text = "\n2) Télécommande (code enregistré)"; textSize = 16f })
        btn(root, "MARCHE") { if (saved >= 0) send(saved, true) }
        btn(root, "ARRÊT") { if (saved >= 0) send(saved, false) }
        btn(root, "Température +") { if (temp < 30) temp++; refresh(); if (saved >= 0) send(saved, true) }
        btn(root, "Température −") { if (temp > 17) temp--; refresh(); if (saved >= 0) send(saved, true) }

        setContentView(root)
    }
}
